# Change Log

## CodeBase version: 2stable.0.1 / 2022-01-15
### Improvements

- Dependencies update (all packages) 
  - Flask==2.0.2 (latest stable version)
  - flask_wtf==1.0.0
  - jinja2==3.0.3
  - flask-restx==0.5.1

